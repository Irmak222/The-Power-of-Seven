package com.sevenup.cardgame;

import com.badlogic.gdx.Game;
import com.sevenup.cardgame.screens.HomeScreen;
import com.sevenup.cardgame.screens.*;
import com.sevenup.cardgame.database.DatabaseInitializer;
import com.sevenup.cardgame.database.DatabaseManager;
import java.sql.Connection;

public class Main extends Game {
    
    @Override
    public void create() {
        DatabaseInitializer.initialize();
        setScreen(new OpeningScreen(this));
    }
   
}
