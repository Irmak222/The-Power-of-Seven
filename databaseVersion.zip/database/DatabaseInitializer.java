package com.sevenup.cardgame.database;

import java.sql.Connection;
import java.sql.Statement;

public class DatabaseInitializer {

    public static void initialize() {
        try (Connection connection = DatabaseManager.connect();
             Statement statement = connection.createStatement()) {

            statement.execute("""
                CREATE TABLE IF NOT EXISTS users(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    totalScore INTEGER DEFAULT 0,
                    gamesPlayed INTEGER DEFAULT 0,
                    gamesWon INTEGER DEFAULT 0,
                    avatar TEXT DEFAULT 'default'
                );
            """);

            System.out.println("Users table ready!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}