package com.sevenup.cardgame.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseManager {

    private static final String URL = "jdbc:sqlite:cardgame.db";

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL);
    }
}