package com.sevenup.cardgame.screens;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton.TextButtonStyle;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.sevenup.cardgame.Main;
import com.sevenup.cardgame.GameManager;
import com.sevenup.cardgame.NumberCard;
import com.sevenup.cardgame.Player;
import com.sevenup.cardgame.ProfileManager;
import com.sevenup.cardgame.ActionCard;
import com.sevenup.cardgame.Card;
import com.sevenup.cardgame.CardProcessor;

public class GameScreen implements Screen {
    private final Main game;
    private final int playerCount; // 3, 4 or 5 player

    private GameManager gameManager;
    private String username;

    private SpriteBatch batch;
    private OrthographicCamera camera;
    private Stage stage;
    private BitmapFont font;
    private BitmapFont bustedFont; 

    private Texture deckPicture; // deck picture
    private Texture emptyCardSlot; // card slots 
    private Texture bustedBackground; 

    private Texture blueButtonTex;   // Freeze button blue
    private Texture greenButtonTex;  // Flip Three button green
    private Texture purpleButtonTex; // Help , flip , stay button purple
    private Texture roundEndTex; // Background round end message
    
    // tables for organization
    private Table controlPanel;
    private Table[] playerAreas;
    private Table[] cardsGrids;
    private Table[] bustedPanels;
    private Table roundEndPanel;

    // Labels for status and scores
    private Label turnLabel; // shows which player's turn
    private Label[] playerScoreLabels;
    private Label roundEndLabel;

    // next round button on the round end panel
    private TextButton nextRoundButton;

    // Stores the currentle drawn Action card that waits player action
    private ActionCard activeActioncard = null;
    
    public GameScreen(Main game, int playerCount, ArrayList<String> registeredPlayerNames, String username) {
        this.game = game;
        this.playerCount = playerCount;
        this.gameManager = new GameManager();
        this.username = username;
        
        // Add registered players or create guest players
        for(int i = 0; i < playerCount; i++) {
            String name;
            boolean isGuest; 

            if(registeredPlayerNames != null && i < registeredPlayerNames.size()) {
                name = registeredPlayerNames.get(i);
                isGuest = false;
            } else {
                name = "Guest Player " + (i + 1);
                isGuest = true;
            }

            this.gameManager.addPlayer(new Player(name, isGuest));
        }
    }

    @Override
    public void show() {
        // Initialize rendering elements
        batch = new SpriteBatch();
        camera = new OrthographicCamera();

        // Create the Stage with ScreenViewport to scale UI elements to screen pixels
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        // Using font file for button text's fonts
        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("ARIAL.TTF"));
        FreeTypeFontParameter parameter = new FreeTypeFontParameter();
        parameter.size = 20;
        parameter.color = Color.BLACK;
        parameter.minFilter = Texture.TextureFilter.Linear;
        parameter.magFilter = Texture.TextureFilter.Linear;
        font = generator.generateFont(parameter);

        // Busted message font
        FreeTypeFontParameter bustedParameter = new FreeTypeFontParameter();
        bustedParameter.size = 48;
        bustedParameter.color = Color.WHITE;
        bustedParameter.minFilter = Texture.TextureFilter.Linear;
        bustedParameter.magFilter = Texture.TextureFilter.Linear;
        bustedFont = generator.generateFont(bustedParameter);

        generator.dispose();

        // Card slots
        emptyCardSlot = createBorderedTexture(75, 100, new Color(0.5f, 0.2f, 0.6f, 1f));

        // Busted message background
        bustedBackground = createTransparentTexture(1, 1, new Color(139f / 255f, 26f / 255f, 26f / 255f,0.65f));

        // Buttons on this screen
        blueButtonTex = createButtonTexture(100, 35, new Color(0.7f, 0.8f, 1f, 1f), Color.BLACK);   
        greenButtonTex = createButtonTexture(140, 35, new Color(0.6f, 0.9f, 0.7f, 1f), Color.BLACK); 
        purpleButtonTex = createButtonTexture(85, 35, new Color(0.85f, 0.8f, 0.95f, 1f), Color.BLACK); 

        // Round end message backgraound
        roundEndTex = createTransparentTexture(1, 1, new Color(0.2f, 0.1f, 0.35f, 0.92f));

        initializeControlPanel();
        initializePlayerAreas();
        buildDynamicLayout();
        initializeRoundEndPanel();
        updateTurnDisplay();
        updateScoresDisplay();
        updatePlayerCardsAndBustedStates();
        System.out.println("Actors: " + stage.getActors().size);
    }

    // creating buttons textures
    private Texture createButtonTexture(int width, int height, Color bgColor, Color borderColor) {
        Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.RGBA8888);
        pixmap.setColor(bgColor);
        pixmap.fill();
        pixmap.setColor(borderColor);
        pixmap.drawRectangle(0, 0, width, height);
        Texture texture = new Texture(pixmap);
        pixmap.dispose();
        return texture;
    }

    // Creating rectangles for card slots
    private Texture createBorderedTexture(int width, int height, Color color) {
        Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.RGBA8888);
        pixmap.setColor(color);
        pixmap.drawRectangle(0, 0, width, height);
        Texture texture = new Texture(pixmap);
        pixmap.dispose();
        return texture;
    }

    // Creating transparent background for busted and round messages
    private Texture createTransparentTexture(int width, int height, Color color) {
        Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.RGBA8888);
        pixmap.setColor(color);
        pixmap.fill();
        Texture texture = new Texture(pixmap);
        pixmap.dispose();
        return texture;
    }

    // Initializing control panel that has deck image, turn status, Flip, Stay and Help buttons
    private void initializeControlPanel() {
        controlPanel = new Table();

        LabelStyle labelStyle = new LabelStyle(font, Color.BLACK);

        TextButtonStyle purpleStyle = new TextButtonStyle();
        purpleStyle.font = font;
        purpleStyle.fontColor = Color.BLACK;
        purpleStyle.up = new TextureRegionDrawable(purpleButtonTex);

        deckPicture = new Texture(Gdx.files.internal("BackOfTheCard.png"));
        Image deckImage = new Image(deckPicture);

        turnLabel = new Label("", labelStyle);

        // Buttons
        TextButton flipButton = new TextButton("Flip", purpleStyle);
        TextButton stayButton = new TextButton("Stay", purpleStyle);
        TextButton helpButton = new TextButton("Help", purpleStyle);

        // When flip button is clicked, player flips a card form the deck
        flipButton.addListener(new ClickListener() {
           @Override
            public void clicked(InputEvent event, float x, float y) {
                if (activeActioncard != null) { 
                    return;
                } 

                Player currentPlayer = gameManager.getPlayers().get(gameManager.getCurrentPlayerIndex());
                // if the player is not frozen and not busted
                if(!currentPlayer.isFrozen() && !currentPlayer.isBusted()) {
                    // draw a card
                    Card drawnCard = gameManager.getDeck().draw();
                    // add to the player's hand
                    currentPlayer.addCardToHand(drawnCard, gameManager.getDeck());
                    
                    // if the drawn card is an action card
                    if (drawnCard instanceof ActionCard) {
                        ActionCard actionCard = (ActionCard) drawnCard;
                        // player uses the actio card according to its type
                        if (actionCard.getActionType().equals(ActionCard.FREEZE) || actionCard.getActionType().equals(ActionCard.FLIP_THREE)) {
                            activeActioncard = actionCard;
                        } else {
                            // otherwise next player flips
                            gameManager.passTurn();
                        }
                    } else {
                        if (!currentPlayer.isSecondChanceUsed()) {
                            gameManager.passTurn();
                        }
                    }

                    // Updates turns, scores, cards, and status
                    updateTurnDisplay();
                    updateScoresDisplay();
                    updatePlayerCardsAndBustedStates();
                    checkRoundStatus();
                }
            }
        });

        // When stay button is clicked, player stays, does not flip a card, and player turn is changed.
        stayButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if(activeActioncard != null) {
                    return;
                }

                gameManager.stay(); 
                gameManager.passTurn(); 
                updateTurnDisplay();
                updatePlayerCardsAndBustedStates();
                checkRoundStatus();
            }
        });

        // When help button is clicked, player goes to the rules page
        helpButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                //game.setScreen(new RulesScreen());
            }
        });

        // Card deck and help button
        Table deckTable = new Table();
        deckTable.add(deckImage).width(80).height(110).row();
        deckTable.add(helpButton).width(75).height(30).padTop(8);

        // Turn label, flip and stay button
        Table actionTable = new Table();
        actionTable.add(turnLabel).padBottom(5).row();
        actionTable.add(flipButton).padBottom(5).width(80).height(35).row();
        actionTable.add(stayButton).width(80).height(35);
        
        controlPanel.add(deckTable).pad(15);
        controlPanel.add(actionTable).pad(15);
    }

    // Initializing card grids, scores, and action buttons for players
    private void initializePlayerAreas() {
        playerAreas = new Table[playerCount];
        playerScoreLabels = new Label[playerCount];
        cardsGrids = new Table[playerCount];
        bustedPanels = new Table[playerCount];

        LabelStyle labelStyle = new LabelStyle(font, Color.BLACK);
        LabelStyle bustedLabelStyle = new LabelStyle(bustedFont, Color.WHITE);

        // Freeze button style 
        TextButtonStyle blueStyle = new TextButtonStyle();
        blueStyle.font = font;
        blueStyle.fontColor = Color.BLACK;
        blueStyle.up = new TextureRegionDrawable(blueButtonTex);

        // Flip Three button style
        TextButtonStyle greenStyle = new TextButtonStyle();
        greenStyle.font = font;
        greenStyle.fontColor = Color.BLACK;
        greenStyle.up = new TextureRegionDrawable(greenButtonTex);

        for(int i = 0; i < playerCount; i++) {
            final int playerIndex = i;
            Table area = new Table();

            Player currentPlayer = gameManager.getPlayers().get(i);
            String name = currentPlayer.getName();
            int score = currentPlayer.getTotalScore();

            Label nameLabel = new Label(name + "\nScore: " + score, labelStyle);
            playerScoreLabels[i] = nameLabel;

            TextButton freezeButton = new TextButton("Freeze", blueStyle);
            TextButton flipThreeButton = new TextButton("Flip Three", greenStyle);

            // Freeze the target player
            freezeButton.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    if (activeActioncard != null && ActionCard.FREEZE.equals(activeActioncard.getActionType())) {
                        int currentIndex = gameManager.getCurrentPlayerIndex();
                        Player currentPLayer = gameManager.getPlayers().get(currentIndex);
                        Player targetPlayer = gameManager.getPlayers().get(playerIndex);
            
                        // player who draws a freeze card can freeze any player that is not frozen or busted (including self if there is not other option)
                        if (!targetPlayer.isFrozen() && !targetPlayer.isBusted()) {
                            CardProcessor.playFreeze(targetPlayer);
                            
                            // remove the freeze card from the player's hand
                            currentPLayer.getActiveHand().remove(activeActioncard);
                            gameManager.getDeck().discard(activeActioncard);
                            activeActioncard = null; 

                            gameManager.passTurn();
                
                            // Update turns, scores, cards, and status
                            updateTurnDisplay();
                            updateScoresDisplay();
                            updatePlayerCardsAndBustedStates();
                            checkRoundStatus();
                        }
                    }
                }
            });

            // Flip three cards 
            flipThreeButton.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    int currentIndex = gameManager.getCurrentPlayerIndex();
        
                    if (activeActioncard != null && ActionCard.FLIP_THREE.equals(activeActioncard.getActionType()) && playerIndex == currentIndex) {
                        Player currentPlayer = gameManager.getPlayers().get(currentIndex);

                        // remove flip three card from the player's hand
                        currentPlayer.getActiveHand().remove(activeActioncard);
                        gameManager.getDeck().discard(activeActioncard);
                        activeActioncard = null;

                        CardProcessor.flipThree(currentPlayer, gameManager.getDeck());
            
                        gameManager.passTurn();

                        // updatet turns, scores, cards and status
                        updateTurnDisplay();
                        updateScoresDisplay();
                        updatePlayerCardsAndBustedStates();
                        checkRoundStatus();
                    }
                }
            });

            // Table that contains player's name, freeze and flip three button
            Table infoRow = new Table();
            infoRow.add(nameLabel).padRight(15);
            infoRow.add(freezeButton).width(90).height(32).padRight(10);
            infoRow.add(flipThreeButton).width(130).height(32);

            Table cardsGrid = new Table();
            cardsGrids[i] = cardsGrid;

            // Busted message panel
            Table bustedPanel = new Table();
            bustedPanel.setBackground(new Image(bustedBackground).getDrawable());
            Label bustedText = new Label("Busted", bustedLabelStyle);
            bustedPanel.add(bustedText).center();
            bustedPanel.setVisible(false);
            bustedPanels[i] = bustedPanel;

            // Stack card slots and busted message over each other
            Stack cardStack = new Stack();
            cardStack.add(cardsGrid);
            cardStack.add(bustedPanel);

            area.add(cardStack).padBottom(10).row();
            area.add(infoRow);

            playerAreas[i] = area;
        }
    }

    // Create a round end message panel for each round end
    public void initializeRoundEndPanel() {
        roundEndPanel = new Table();
        roundEndPanel.setBackground(new TextureRegionDrawable(roundEndTex));

        LabelStyle labelStyle = new LabelStyle(bustedFont, Color.WHITE);
        roundEndLabel = new Label("Round Ended!", labelStyle);

        TextButtonStyle purpleStyle = new TextButtonStyle();
        purpleStyle.font = font;
        purpleStyle.fontColor = Color.BLACK;
        purpleStyle.up = new TextureRegionDrawable(purpleButtonTex);

        nextRoundButton = new TextButton("Next Round", purpleStyle); 
        TextButton mainMenuButton = new TextButton("Main Menu", purpleStyle);

        // when next round button is clicked, current hands are cleared and new rouns is started
        nextRoundButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                gameManager.startNewRound();
                roundEndPanel.setVisible(false);
                updateTurnDisplay();
                updateScoresDisplay();
                updatePlayerCardsAndBustedStates();
            }
        });

        // when main menu button is clicked, opening screen will appear
        mainMenuButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new OpeningScreen(game)); 
            }
        });

        // Adding labels and buttons to the round end panel
        roundEndPanel.add(roundEndLabel).padBottom(30).colspan(2).row();
        roundEndPanel.add(nextRoundButton).width(160).height(45).padRight(20);
        roundEndPanel.add(mainMenuButton).width(160).height(45);
        roundEndPanel.setVisible(false);
        roundEndPanel.toFront();

        stage.addActor(roundEndPanel);
        roundEndPanel.setSize(480, 220);
        // place the round end panel to the center of the screen
        roundEndPanel.setPosition((Gdx.graphics.getWidth() - roundEndPanel.getWidth()) / 2f, (Gdx.graphics.getHeight() - roundEndPanel.getHeight()) / 2f);
    }
    
    // Updating card slots for all players 
    public void updatePlayerCardsAndBustedStates() {
        for (int i = 0; i < playerCount; i++) {
            Player player = gameManager.getPlayers().get(i); 
            Table grid = cardsGrids[i];
            grid.clearChildren(); // clear 
            
            ArrayList<Card> hand = player.getActiveHand(); 
            ArrayList<Card> numberCards = new ArrayList<>();
            ArrayList<Card> actionAndModifiers = new ArrayList<>();

            for(Card card : hand) {
                if(card instanceof NumberCard) { 
                    numberCards.add(card);
                } else {
                    actionAndModifiers.add(card);
                }
            }

            // First row of card slots for number cards
            for (int col = 0; col < 7; col++) {
                if (col < numberCards.size()) {
                    Card currentCard = numberCards.get(col);
                    // Card image added
                    Image cardImage = new Image(currentCard.getImage());
                    grid.add(cardImage).width(60).height(88).pad(3);
                } else {
                    Image cardSlot = new Image(emptyCardSlot);
                    grid.add(cardSlot).width(60).height(88).pad(3);
                }
            }
            grid.row(); 

            // Second row of card slots for modifier and action cards
            for (int col = 0; col < 7; col++) {
                if (col < actionAndModifiers.size()) {
                    Card currentCard = actionAndModifiers.get(col);
                    // Card image added
                    Image cardImage = new Image(currentCard.getImage());
                    grid.add(cardImage).width(60).height(88).pad(3);
                } else {
                    Image cardSlot = new Image(emptyCardSlot);
                    grid.add(cardSlot).width(60).height(88).pad(3);
                }
            }

            // if the player is busted, shpw the busted message
            if (player.isBusted()) { 
                bustedPanels[i].setVisible(true);
            } else {
                bustedPanels[i].setVisible(false);
            }
        }
    }

    // Building player areas depending on total player count
    private void buildDynamicLayout() {
        Table mainTable = new Table();
        mainTable.setFillParent(true);

        mainTable.padLeft(30).padRight(30).padTop(10).padBottom(10);

        if (playerCount == 4) {
            mainTable.add(playerAreas[0]).expand().center().padLeft(40);
            mainTable.add(playerAreas[1]).expand().center().padRight(40);
            mainTable.row();
            mainTable.add(controlPanel).colspan(2).height(130).center();
            mainTable.row();
            mainTable.add(playerAreas[2]).expand().center().padLeft(40);
            mainTable.add(playerAreas[3]).expand().center().padRight(40);
        } else if (playerCount == 3) {
            mainTable.add(playerAreas[0]).expand().center();
            mainTable.add(controlPanel).expand().center();
            mainTable.row();
            mainTable.add(playerAreas[1]).expand().center();
            mainTable.add(playerAreas[2]).expand().center();
        } else if (playerCount == 5) {
            mainTable.add(playerAreas[0]).expand().pad(5);
            mainTable.add(playerAreas[1]).expand().pad(5);
            mainTable.add(playerAreas[2]).expand().pad(5);
            mainTable.row();
            mainTable.add(playerAreas[3]).expand().pad(5);
            mainTable.add(playerAreas[4]).expand().pad(5);
            mainTable.add(controlPanel).expand().pad(5);
        }
        stage.addActor(mainTable);
    }

    // Updating turn status (shows current player's turn or special action senetnces according to drawn card)
    public void updateTurnDisplay() {
        if(turnLabel != null) {
            int currentIndex = gameManager.getCurrentPlayerIndex();
            Player currentPlayer = gameManager.getPlayers().get(currentIndex);
            
            String status = "'s Turn";
            if(currentPlayer.isSecondChanceUsed()) {
                status = " Saved by Secod Chance!";
            } else if (activeActioncard != null) {
                if (ActionCard.FREEZE.equals(activeActioncard.getActionType())) {
                    status = " (Choose player to FREEZE!)";
                } else if (ActionCard.FLIP_THREE.equals(activeActioncard.getActionType())) {
                    status = " (Click your Flip Three button!)";
                }
            } else if (currentPlayer.isFrozen()) {
                status = " (Stayed)";
            }

            turnLabel.setText(currentPlayer.getName() + status);
        }
    }

    // Updating player score text
    public void updateScoresDisplay() {
        for (int i = 0; i < playerCount; i++) {
            if (playerScoreLabels[i] != null) {
                Player player = gameManager.getPlayers().get(i);
                int score = 0;
                String status = "";

                if (player.isBusted()) {
                    score = 0;
                } else if (player.isFrozen()) {
                    score = CardProcessor.calculateHandScore(player.getActiveHand());
                    status = "(Frozen)"; // if the player is frozen, "(Frozen)" is added next to the player's name
                } else {
                    for (Card card : player.getActiveHand()) {
                        if (card instanceof NumberCard) {
                            score += ((NumberCard) card).getValue();
                        }
                    }
                }

                playerScoreLabels[i].setText(player.getName() + status + "\nScore: " + score);
            }
        }
    }

    // Checks if the current round is completed and shows the round end messages
    public void checkRoundStatus() {
        if (gameManager.isRoundOver()) {
            
            String endMessage = "ROUND OVER!";
            boolean foundWinner = false;

            // Check if any active player flipped 7 unique number cards
            for (int i = 0; i < gameManager.getPlayers().size() && !foundWinner; i++) {
                Player p = gameManager.getPlayers().get(i);
                
                if (!p.isBusted()) {
                    if (gameManager.hasSevenUniqueNumbers(p)) {
                        int roundScore = CardProcessor.calculateHandScore(p.getActiveHand());
                        int totalScoreAfterRound = p.getTotalScore() + roundScore + 15; // adds 15 bonus points to total score
                        
                        endMessage = p.getName() + " FLIPPED 7 CARDS!\n(+15 Bonus Points!)\nRound Score: " + roundScore + " | Total Score: " + totalScoreAfterRound;
                        foundWinner = true; 
                    }
                }
            }

            // If no one flipped 7 unique number cards, find the highest hand score
            if (!foundWinner) {
                Player roundWinner = null;
                int maxRoundScore = -1;

                for (Player player : gameManager.getPlayers()) {
                    if (!player.isBusted()) {
                        int score = CardProcessor.calculateHandScore(player.getActiveHand());
                        if (score > maxRoundScore) {
                            maxRoundScore = score;
                            roundWinner = player;
                        }
                    }
                }

                if (roundWinner != null) {
                    int totalScoreAfterRound = roundWinner.getTotalScore() + maxRoundScore;
                    endMessage = roundWinner.getName() + " Won The Round!\nRound Score: " + maxRoundScore + " | Total Score: " + totalScoreAfterRound;
                } else {
                    endMessage = "ROUND OVER!\nEveryone Busted!";
                }
            }

            updateScoresDisplay();
            updatePlayerCardsAndBustedStates();
            gameManager.finalizeRound();
            // check if the game is over
            if (gameManager.isGameOver()) {

    Player winner = gameManager.getPlayers().get(0);

    for (Player player : gameManager.getPlayers()) {
        if (player.getTotalScore() > winner.getTotalScore()) {
            winner = player;
        }
    }

    ProfileManager pm = new ProfileManager();

    try {
        for (Player player : gameManager.getPlayers()) {

            if (!player.isGuest()) {

                int gamesPlayed = pm.getGamesPlayed(player.getName()) + 1;
                int gamesWon = pm.getGamesWon(player.getName());

                if (player == winner) {
                    gamesWon++;
                }
                
                pm.saveStats(
                    player.getName(),
                    player.getTotalScore(),
                    gamesPlayed,
                    gamesWon
                );
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    roundEndLabel.setText(
            "GAME OVER!\nWinner: "
            + winner.getName()
            + "\nFinal Score: "
            + winner.getTotalScore());

    nextRoundButton.setVisible(false);

} else {
    roundEndLabel.setText(endMessage);
    nextRoundButton.setVisible(true);
}

            float roundEndPanelWidth = 900f;  
            float roundEndPanelHeight = 450f; 
            
            roundEndPanel.setSize(roundEndPanelWidth, roundEndPanelHeight);
            // Place the round end message panel at the center
            roundEndPanel.setPosition((Gdx.graphics.getWidth() - roundEndPanelWidth) / 2f,(Gdx.graphics.getHeight() - roundEndPanelHeight) / 2f);

            roundEndPanel.setVisible(true);
            roundEndPanel.toFront();

        }
    }

    @Override
    public void render(float delta) {
        // Clear the screen
        Gdx.gl.glClearColor(238f / 255f, 231f / 255f, 255f / 255f, 1f); // background color
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Updating metrics to solve multidisplay pixel conflicts
        camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.update();

        batch.setProjectionMatrix(camera.combined);

        // Update and draw the UI buttons
        stage.act(delta);
        stage.draw();
        
    }

    @Override
    public void resize(int width, int height) {
        // Update stage sizes when the window size changes
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {
        
    }

    @Override
    public void resume() {
        
    }

    @Override
    public void hide() {
        
    }

    @Override
    public void dispose() {
        batch.dispose();
        stage.dispose();
        font.dispose();
        bustedFont.dispose();
        deckPicture.dispose();
        emptyCardSlot.dispose();
        bustedBackground.dispose();
        blueButtonTex.dispose();
        greenButtonTex.dispose();
        purpleButtonTex.dispose();
    }
}