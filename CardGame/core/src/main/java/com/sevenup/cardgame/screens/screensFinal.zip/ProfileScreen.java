package com.sevenup.cardgame.screens;

import java.sql.ResultSet;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import com.sevenup.cardgame.Main;
import com.sevenup.cardgame.ProfileManager;

public class ProfileScreen implements Screen {

    private Main game;
    private String username;

    private Stage stage;
    private Skin skin;
    private SpriteBatch batch;
    private Texture background;
    private OrthographicCamera camera;


    public ProfileScreen(Main game, String username) {
        this.game = game;
        this.username = username;
    }

    @Override
    public void show() {
        batch = new SpriteBatch();
        background = new Texture(Gdx.files.internal("OpeningScreen.png")); // background picture
        camera = new OrthographicCamera();

        // Create the stage with screenviewport to scale UI elements to screen pixels
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        skin = new Skin(Gdx.files.internal("ui/uiskin.json"));

        Table table = new Table();
        table.setFillParent(true);
        table.pad(40);

        stage.addActor(table);

        //Label title = new Label("MY PROFILE", skin);
        //title.setFontScale(2f);
        //title.setColor(Color.GOLD);

        String user = "";
        int totalScore = 0;
        int gamesPlayed = 0;
        int gamesWon = 0;
        String avatar = "";

        try {

            ProfileManager pm = new ProfileManager();
            ResultSet rs = pm.getProfile(username);

            if (rs.next()) {

                user = rs.getString("username");
                totalScore = rs.getInt("totalScore");
                gamesPlayed = rs.getInt("gamesPlayed");
                gamesWon = rs.getInt("gamesWon");
                //avatar = rs.getString("avatar");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        //Label avatarLabel = new Label("Avatar : " + avatar, skin);
        Label usernameLabel = new Label("Username : " + user, skin);
        usernameLabel.setColor(Color.BLUE);
        Label scoreLabel = new Label("Total Score : " + totalScore, skin);
        scoreLabel.setColor(Color.BLUE);
        Label playedLabel = new Label("Games Played : " + gamesPlayed, skin);
        playedLabel.setColor(Color.BLUE);
        Label wonLabel = new Label("Games Won : " + gamesWon, skin);
        wonLabel.setColor(Color.BLUE);

        //TextButton changeAvatar = new TextButton("Change Avatar", skin);

        TextButton back = new TextButton("Main Menu", skin);

        back.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new HomeScreen(game, username));
            }
        });

        //table.add(title).padBottom(40);
        //table.row();

        //table.add(avatarLabel).pad(10);
        //table.row();

        table.add(usernameLabel).pad(10);
        table.row();

        table.add(scoreLabel).pad(10);
        table.row();

        table.add(playedLabel).pad(10);
        table.row();

        table.add(wonLabel).pad(10);
        table.row();

        //table.add(changeAvatar)
               // .width(220)
                //.height(60)
                //.padTop(30);

        table.row();

        table.add(back)
                .width(220)
                .height(60)
                .padTop(15);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.update();

        batch.setProjectionMatrix(camera.combined);

        batch.begin();
        batch.draw(background, 0, 0,
                Gdx.graphics.getWidth(),
                Gdx.graphics.getHeight());
        batch.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
    batch.dispose();
    stage.dispose();
    skin.dispose();
    background.dispose();

    }
}